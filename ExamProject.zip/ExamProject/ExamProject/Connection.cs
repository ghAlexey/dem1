﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamProject
{
    public static class Connection
    {
        public static string connectionString = "Server=DESKTOP-0DQ2BPO;Database=ExamDB;Integrated Security=True;TrustServerCertificate=True";

    }
}
