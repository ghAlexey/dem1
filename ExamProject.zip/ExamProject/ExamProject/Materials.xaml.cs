﻿using Microsoft.Data.SqlClient;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using Dapper;

namespace ExamProject
{
    public partial class Materials : Window, INotifyPropertyChanged
    {
        private ObservableCollection<MaterialViewModel> _materialItems;
        public ObservableCollection<MaterialViewModel> MaterialItems
        {
            get => _materialItems;
            set
            {
                _materialItems = value;
                OnPropertyChanged();
            }
        }

        public Materials()
        {
            InitializeComponent();
            DataContext = this;
            LoadMaterials();
        }

        public void Refresh_Click(object sender, RoutedEventArgs e)
        {
            LoadMaterials();
        }

        public void Back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private async void LoadMaterials()
        {
            try
            {
                using (var conn = new SqlConnection(Connection.connectionString))
                {
                    conn.Open();
                    var commandText = @"SELECT
                        m.MaterialID,
                        m.Name,
                        m.StockQuantity,
                        m.MinStockQuantity,
                        COALESCE(SUM(mu.RequiredAmount), 0) AS RequiredAmount,
                        m.UnitPrice    
                        FROM Material m
                        LEFT JOIN MaterialUsage mu ON m.MaterialID = mu.MaterialID
                        GROUP BY m.MaterialID, m.Name, m.StockQuantity, m.MinStockQuantity, m.UnitPrice";
                    using (var command = new SqlCommand(commandText, conn))
                        using(var reader = await command.ExecuteReaderAsync())
                    {
                        var materials = new List<MaterialViewModel>();
                        while( await reader.ReadAsync())
                        {
                            materials.Add(new MaterialViewModel
                            {
                                MaterialID = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                StockQuantity = reader.GetInt32(2),
                                MinStockQuantity = reader.GetInt32(3),
                                RequiredAmount = reader.GetDecimal(4),
                                UnitPrice = reader.GetDecimal(5),
                            });
                        }
                        MaterialItems = new ObservableCollection<MaterialViewModel>(materials);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show($"Ошибка {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class MaterialViewModel : INotifyPropertyChanged
    {


        private ObservableCollection<ProductUsageViewModel> _usedInProducts;
        public ObservableCollection<ProductUsageViewModel> UsedInProducts
        {
            get => _usedInProducts;
            set
            {
                _usedInProducts = value;
                OnPropertyChanged();
            }
        }

        public async Task LoadProductUsageData()
        {
            try
            {
                using (var conn = new SqlConnection(Connection.connectionString))
                {
                    await conn.OpenAsync();
                    var query = @"
                    SELECT 
                        p.Name AS ProductName,
                        p.ProductCode,
                        mu.RequiredAmount
                        FROM MaterialUsage mu
                        JOIN Product p ON mu.ProductID = p.ProductID
                        WHERE mu.MaterialID = @MaterialID";

                    UsedInProducts = new ObservableCollection<ProductUsageViewModel>(
                        await conn.QueryAsync<ProductUsageViewModel>(query, new { MaterialID })
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }


        public ICommand SaveCommand { get; }

        public MaterialViewModel()
        {
            SaveCommand = new RelayCommand(async _ => await SaveChanges());
            EditCommand = new RelayCommand(OpenEditWindow);

        }

        private bool ValidateFields()
        {
            var errors = new List<string>();

            if (StockQuantity < 0)
                errors.Add("Количество на складе не может быть отрицательным");

            if (MinStockQuantity < 0)
                errors.Add("Минимальный запас не может быть отрицательным");

            if (UnitPrice <= 0)
                errors.Add("Цена должна быть положительной");

            if (errors.Any())
            {
                MessageBox.Show(string.Join("\n", errors), "Ошибки валидации");
                return false;
            }

            return true;
        }

        public async Task SaveChanges()
        {
            if (!ValidateFields()) return;
            try
            {
                using (var conn = new SqlConnection(Connection.connectionString))
                {
                    await conn.OpenAsync();

                    var sql = @"
                    UPDATE Material 
                    SET 
                        Name = @Name,
                        StockQuantity = @StockQuantity,
                        MinStockQuantity = @MinStockQuantity,
                        UnitPrice = @UnitPrice,
                        UnitOfMeasure = @UnitOfMeasure,
                        PackageQuantity = @PackageQuantity
                    WHERE MaterialID = @MaterialID";

                    var affectedRows = await conn.ExecuteAsync(sql, new
                    {
                        Name,
                        StockQuantity,
                        MinStockQuantity,
                        UnitPrice,
                        UnitOfMeasure,
                        PackageQuantity,
                        MaterialID
                    });

                    if (affectedRows > 0)
                    {
                        MessageBox.Show("Изменения успешно сохранены");
                        RequestClose?.Invoke(this, EventArgs.Empty);
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ошибка базы данных: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        public event EventHandler RequestClose;

        public ICommand EditCommand { get; }


        private void OpenEditWindow(object parameter)
        {
            var editWindow = new MaterialEditWindow(this);
            editWindow.ShowDialog();
        }

        private int _materialId;
        public int MaterialID
        {
            get => _materialId;
            set
            {
                _materialId = value;
                OnPropertyChanged();
            }
        }

        private string _name;
        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged(); }
        }

        private int _stockQuantity;
        public int StockQuantity
        {
            get => _stockQuantity;
            set { _stockQuantity = value; OnPropertyChanged(); }
        }

        private decimal _requiredAmount;
        public decimal RequiredAmount
        {
            get => _requiredAmount;
            set { _requiredAmount = value; OnPropertyChanged(); }
        }

        private int _minStockQuantity;
        public int MinStockQuantity
        {
            get => _minStockQuantity;
            set { _minStockQuantity = value; OnPropertyChanged(); }
        }

        private decimal _unitPrice;
        public decimal UnitPrice
        {
            get => _unitPrice;
            set { _unitPrice = value; OnPropertyChanged(); }
        }

        private string _unitOfMeasure;
        public string UnitOfMeasure
        {
            get => _unitOfMeasure;
            set { _unitOfMeasure = value; OnPropertyChanged(); }
        }

        private decimal _packageQuantity;
        public decimal PackageQuantity
        {
            get => _packageQuantity;
            set { _packageQuantity = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}