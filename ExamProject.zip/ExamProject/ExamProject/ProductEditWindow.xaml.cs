﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Dapper;

namespace ExamProject
{
    /// <summary>
    /// Логика взаимодействия для ProductEditWindow.xaml
    /// </summary>
    public partial class ProductEditWindow : Window
    {

        private ProductViewModel _originalProduct;

        public ProductViewModel CurrentProduct { get; set; }
        public ObservableCollection<ProductTypeViewModel> ProductTypes { get; } = new();
        public ObservableCollection<MaterialViewModel> AllMaterials { get; } = new();
        public ObservableCollection<MaterialUsageViewModel> MaterialUsages { get; } = new();

        public ProductEditWindow(ProductViewModel product)
        {
            InitializeComponent();
            CurrentProduct = new ProductViewModel
            {
                ProductID = product.ProductID,
                Name = product.Name,
                ProductCode = product.ProductCode,
                MinPartnerPrice = product.MinPartnerPrice,
                ProductType = product.ProductType
            };


            LoadDataAsync().ConfigureAwait(false);
        }

        private async Task LoadDataAsync()
        {
            try
            {
                using (var conn = new SqlConnection(Connection.connectionString))
                {
                    // Загрузка типов продукции
                    var productTypes = await conn.QueryAsync<ProductTypeViewModel>(
                        "SELECT TypeID, TypeName FROM ProductType");
                    foreach (var productType in productTypes)
                    {
                        ProductTypes.Add(productType);
                    }

                    // Загрузка всех материалов
                    var materials = await conn.QueryAsync<MaterialViewModel>(
                        "SELECT MaterialID, Name FROM Material");
                    foreach (var material in materials)
                    {
                        AllMaterials.Add(material);
                    }

                    // Загрузка текущего использования материалов
                    var usages = await conn.QueryAsync<MaterialUsageViewModel>(
                        @"SELECT MaterialID AS MaterialId, RequiredAmount 
                     FROM MaterialUsage 
                     WHERE ProductID = @ProductId",
                        new { ProductId = CurrentProduct.ProductID });
                    foreach(var usage in usages)
                    {
                        MaterialUsages.Add(usage);
                    }

                    txtName.Text = CurrentProduct.Name;

                    txtProductCode.Text = CurrentProduct.ProductCode;

                    txtMinPartnerPrice.Text = CurrentProduct.MinPartnerPrice.ToString();

                    cmbProductTypes.ItemsSource = ProductTypes;
                    cmbProductTypes.SelectedIndex = CurrentProduct.ProductType.TypeID;
                    cmbProductTypes.DisplayMemberPath = "TypeName";
                    cmbProductTypes.SelectedValuePath = "TypeID";

                    dgMaterialUsages.ItemsSource = MaterialUsages;

                    dgcmbAllMaterials.ItemsSource = AllMaterials;
                    dgcmbAllMaterials.DisplayMemberPath = "Name";
                    dgcmbAllMaterials.SelectedValuePath = "MaterialID";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        private void AddMaterial(object sander, RoutedEventArgs e)
        {
            MaterialUsages.Add(new MaterialUsageViewModel
            {
                ProductId = CurrentProduct.ProductID,
                MaterialId = AllMaterials.FirstOrDefault()?.MaterialID ?? 0,
                RequiredAmount = 0
            });
        }

        private async void SaveProduct(object sander, RoutedEventArgs e)
        {
            if (!Validate()) return;

            using (var conn = new SqlConnection(Connection.connectionString))
            {
                await conn.OpenAsync();
                using (var transaction = conn.BeginTransaction())
                {
                    try
                    {
                        // Обновление продукта
                        await conn.ExecuteAsync(
                            @"UPDATE Product SET 
                            Name = @Name,
                            ProductCode = @ProductCode,
                            MinPartnerPrice = @MinPartnerPrice,
                            TypeID = @TypeId
                         WHERE ProductID = @ProductID",
                            new
                            {
                                CurrentProduct.Name,
                                CurrentProduct.ProductCode,
                                CurrentProduct.MinPartnerPrice,
                                TypeId = CurrentProduct.ProductType.TypeID,
                                CurrentProduct.ProductID
                            }, transaction);

                        // Обновление материалов
                        await conn.ExecuteAsync(
                            "DELETE FROM MaterialUsage WHERE ProductID = @ProductId",
                            new { CurrentProduct.ProductID }, transaction);

                        foreach (var usage in MaterialUsages)
                        {
                            await conn.ExecuteAsync(
                                @"INSERT INTO MaterialUsage 
                            (ProductID, MaterialID, RequiredAmount)
                            VALUES (@ProductId, @MaterialId, @RequiredAmount)",
                                new
                                {
                                    ProductId = CurrentProduct.ProductID,
                                    usage.MaterialId,
                                    usage.RequiredAmount
                                }, transaction);
                        }

                        transaction.Commit();
                        MessageBox.Show("Изменения сохранены успешно!");
                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"Ошибка сохранения: {ex.Message}");
                    }
                }
            }
        }

        private void Cancel(object sander, RoutedEventArgs e)
        {
            this.Close();
        }

        private bool Validate()
        {
            var errors = new List<string>();

            if (string.IsNullOrWhiteSpace(CurrentProduct.Name))
                errors.Add("Название продукта обязательно");

            if (CurrentProduct.MinPartnerPrice <= 0)
                errors.Add("Минимальная цена должна быть положительной");

            if (MaterialUsages.Any(u => u.RequiredAmount <= 0))
                errors.Add("Количество материала должно быть больше 0");

            if (errors.Any())
            {
                MessageBox.Show(string.Join("\n", errors), "Ошибки валидации");
                return false;
            }
            return true;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }

    public class MaterialUsageViewModel
    {
        public int ProductId { get; set; }
        public int MaterialId { get; set; }
        public decimal RequiredAmount { get; set; }
    }


}
