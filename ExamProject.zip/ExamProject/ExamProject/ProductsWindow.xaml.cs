﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Dapper;

namespace ExamProject
{
    public partial class ProductsWindow : Window, INotifyPropertyChanged
    {
        private ObservableCollection<ProductViewModel> _products;
        public ObservableCollection<ProductViewModel> Products
        {
            get => _products;
            set
            {
                _products = value;
                OnPropertyChanged();
            }
        }

        public ProductsWindow()
        {
            InitializeComponent();
            DataContext = this;
            LoadProductsAsync().ConfigureAwait(true);
        }

        public async Task LoadProductsAsync()
        {
            try
            {
                using (var conn = new SqlConnection(Connection.connectionString))
                {
                    var query = @"
SELECT 
    p.ProductID,
    p.Name,
    p.ProductCode,
    p.MinPartnerPrice,
    p.TypeID AS ProductTypeID,
    pt.TypeID,
    pt.TypeName,
    pt.ProductCoefficient
FROM Product p
JOIN ProductType pt ON p.TypeID = pt.TypeID";

                    var products = await conn.QueryAsync<ProductViewModel, ProductTypeViewModel, ProductViewModel>(
                        query,
                        (product, type) => {
                            product.ProductType = type;
                            return product;
                        },
                        splitOn: "TypeID");

                    Products = new ObservableCollection<ProductViewModel>(products);
                    icProducts.ItemsSource = Products;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        private void Back(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void Refresh(object sender, RoutedEventArgs e)
        {
            LoadProductsAsync().ConfigureAwait(true);
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class ProductViewModel : INotifyPropertyChanged
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public string ProductCode { get; set; }
        public decimal MinPartnerPrice { get; set; }
        public int ProductTypeID { get; set; } // <--- ВАЖНО: сопоставление с алиасом!
        public ProductTypeViewModel ProductType { get; set; }
        public decimal ProductionCost { get; set; }
        public ICommand EditCommand { get; }

        public ProductViewModel()
        {
            EditCommand = new RelayCommand(OpenEditWindow);
        }

        private ProductTypeViewModel _selectedProductType;
        public ProductTypeViewModel SelectedProductType
        {
            get => _selectedProductType;
            set
            {
                _selectedProductType = value;
                OnPropertyChanged();
            }
        }

        private void OpenEditWindow(object parameter)
        {
            var editWindow = new ProductEditWindow(this);
            editWindow.ShowDialog();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class ProductTypeViewModel
    {
        public int TypeID { get; set; }
        public string TypeName { get; set; }
        public decimal ProductCoefficient { get; set; }
    }
}
