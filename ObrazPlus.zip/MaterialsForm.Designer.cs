﻿namespace ObrazPlus
{
    partial class MaterialsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MaterialsForm));
            this.flowLayoutPanelMaterials = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonToMaterials = new System.Windows.Forms.Button();
            this.buttonToProducts = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonAddMaterial = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanelMaterials
            // 
            this.flowLayoutPanelMaterials.AutoScroll = true;
            this.flowLayoutPanelMaterials.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanelMaterials.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.flowLayoutPanelMaterials.FlowDirection = System.Windows.Forms.FlowDirection.BottomUp;
            this.flowLayoutPanelMaterials.Font = new System.Drawing.Font("Constantia", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flowLayoutPanelMaterials.Location = new System.Drawing.Point(0, 69);
            this.flowLayoutPanelMaterials.Name = "flowLayoutPanelMaterials";
            this.flowLayoutPanelMaterials.Size = new System.Drawing.Size(2128, 776);
            this.flowLayoutPanelMaterials.TabIndex = 0;
            this.flowLayoutPanelMaterials.WrapContents = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Controls.Add(this.buttonAddMaterial);
            this.groupBox1.Controls.Add(this.buttonExit);
            this.groupBox1.Controls.Add(this.buttonToProducts);
            this.groupBox1.Controls.Add(this.buttonToMaterials);
            this.groupBox1.Location = new System.Drawing.Point(0, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(2128, 51);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // buttonToMaterials
            // 
            this.buttonToMaterials.Location = new System.Drawing.Point(23, 5);
            this.buttonToMaterials.Name = "buttonToMaterials";
            this.buttonToMaterials.Size = new System.Drawing.Size(138, 40);
            this.buttonToMaterials.TabIndex = 0;
            this.buttonToMaterials.Text = "Материалы";
            this.buttonToMaterials.UseVisualStyleBackColor = true;
            // 
            // buttonToProducts
            // 
            this.buttonToProducts.Location = new System.Drawing.Point(167, 5);
            this.buttonToProducts.Name = "buttonToProducts";
            this.buttonToProducts.Size = new System.Drawing.Size(132, 40);
            this.buttonToProducts.TabIndex = 2;
            this.buttonToProducts.Text = "Продукция";
            this.buttonToProducts.UseVisualStyleBackColor = true;
            this.buttonToProducts.Click += new System.EventHandler(this.buttonToProducts_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(328, 5);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(127, 40);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "Выход";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonAddMaterial
            // 
            this.buttonAddMaterial.Location = new System.Drawing.Point(1145, 5);
            this.buttonAddMaterial.Name = "buttonAddMaterial";
            this.buttonAddMaterial.Size = new System.Drawing.Size(158, 40);
            this.buttonAddMaterial.TabIndex = 3;
            this.buttonAddMaterial.Text = "Добавить";
            this.buttonAddMaterial.UseVisualStyleBackColor = true;
            this.buttonAddMaterial.Click += new System.EventHandler(this.buttonAddMaterial_Click);
            // 
            // MaterialsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2128, 845);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.flowLayoutPanelMaterials);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MaterialsForm";
            this.Text = "Материалы";
            this.Load += new System.EventHandler(this.MaterialsForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelMaterials;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonToProducts;
        private System.Windows.Forms.Button buttonToMaterials;
        private System.Windows.Forms.Button buttonAddMaterial;
    }
}