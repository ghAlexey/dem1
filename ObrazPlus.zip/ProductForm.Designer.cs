﻿namespace ObrazPlus
{
    partial class ProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductForm));
            this.dataGridViewProducts = new System.Windows.Forms.DataGridView();
            this.buttonShowMaterials = new System.Windows.Forms.Button();
            this.dataGridViewMaterials = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonToProducts = new System.Windows.Forms.Button();
            this.buttonToMaterials = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMaterials)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewProducts
            // 
            this.dataGridViewProducts.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProducts.Location = new System.Drawing.Point(13, 94);
            this.dataGridViewProducts.Name = "dataGridViewProducts";
            this.dataGridViewProducts.RowHeadersWidth = 82;
            this.dataGridViewProducts.RowTemplate.Height = 33;
            this.dataGridViewProducts.Size = new System.Drawing.Size(1849, 434);
            this.dataGridViewProducts.TabIndex = 0;
            // 
            // buttonShowMaterials
            // 
            this.buttonShowMaterials.BackColor = System.Drawing.Color.LightSteelBlue;
            this.buttonShowMaterials.Location = new System.Drawing.Point(549, 4);
            this.buttonShowMaterials.Name = "buttonShowMaterials";
            this.buttonShowMaterials.Size = new System.Drawing.Size(271, 43);
            this.buttonShowMaterials.TabIndex = 1;
            this.buttonShowMaterials.Text = "Показать состав";
            this.buttonShowMaterials.UseVisualStyleBackColor = false;
            // 
            // dataGridViewMaterials
            // 
            this.dataGridViewMaterials.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMaterials.Location = new System.Drawing.Point(13, 561);
            this.dataGridViewMaterials.Name = "dataGridViewMaterials";
            this.dataGridViewMaterials.RowHeadersWidth = 82;
            this.dataGridViewMaterials.RowTemplate.Height = 33;
            this.dataGridViewMaterials.Size = new System.Drawing.Size(1849, 273);
            this.dataGridViewMaterials.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Controls.Add(this.buttonExit);
            this.groupBox1.Controls.Add(this.buttonToProducts);
            this.groupBox1.Controls.Add(this.buttonShowMaterials);
            this.groupBox1.Controls.Add(this.buttonToMaterials);
            this.groupBox1.Location = new System.Drawing.Point(2, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(2128, 51);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(328, 5);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(127, 40);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "Выход";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonToProducts
            // 
            this.buttonToProducts.Location = new System.Drawing.Point(167, 5);
            this.buttonToProducts.Name = "buttonToProducts";
            this.buttonToProducts.Size = new System.Drawing.Size(132, 40);
            this.buttonToProducts.TabIndex = 2;
            this.buttonToProducts.Text = "Продукция";
            this.buttonToProducts.UseVisualStyleBackColor = true;
            // 
            // buttonToMaterials
            // 
            this.buttonToMaterials.Location = new System.Drawing.Point(23, 5);
            this.buttonToMaterials.Name = "buttonToMaterials";
            this.buttonToMaterials.Size = new System.Drawing.Size(138, 40);
            this.buttonToMaterials.TabIndex = 0;
            this.buttonToMaterials.Text = "Материалы";
            this.buttonToMaterials.UseVisualStyleBackColor = true;
            this.buttonToMaterials.Click += new System.EventHandler(this.buttonToMaterials_Click);
            // 
            // ProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2128, 845);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridViewMaterials);
            this.Controls.Add(this.dataGridViewProducts);
            this.Font = new System.Drawing.Font("Constantia", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ProductForm";
            this.Text = "Продукция";
            this.Load += new System.EventHandler(this.ProductForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMaterials)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewProducts;
        private System.Windows.Forms.Button buttonShowMaterials;
        private System.Windows.Forms.DataGridView dataGridViewMaterials;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonToProducts;
        private System.Windows.Forms.Button buttonToMaterials;
    }
}