﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObrazPlus
{
    public partial class ProductForm : Form
    {
        private readonly string _connectionString;

        public ProductForm(string connectionString)
        {
            InitializeComponent();
            _connectionString = connectionString;
        }

        private void LoadProducts()
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                var query = @"
            SELECT p.ProductID, p.ProductName, pt.ProductTypeName, p.Article, p.PartnerPrice
            FROM Products p
            JOIN ProductTypes pt ON p.ProductTypeID = pt.ProductTypeID";
                var adapter = new SqlDataAdapter(query, conn);
                var table = new DataTable();
                adapter.Fill(table);
                dataGridViewProducts.DataSource = table;
            }
        }

        private void ProductForm_Load(object sender, EventArgs e)
        {
            LoadProducts();
        }

        private void buttonShowMaterials_Click(object sender, EventArgs e)
        {

        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonToMaterials_Click(object sender, EventArgs e)
        {
            var productForm = new MaterialsForm(_connectionString);
            productForm.Show();
            this.Hide();
        }
    }
}
